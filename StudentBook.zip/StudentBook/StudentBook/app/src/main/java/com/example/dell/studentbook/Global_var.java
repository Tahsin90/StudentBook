package com.example.dell.studentbook;

/**
 * Created by AKASH on 6/29/2017.
 */

public class Global_var {

    double Ch[]=new double[10];

    public double getCh(int pos) {
        return Ch[pos];
    }

    public void setCh(int pos,double value) {
        Ch[pos] = value;
    }

    double Gp[]=new double[10];

    public double getGp(int pos) {
        return Gp[pos];
    }

    public void setGp(int pos,double value) {
        Gp[pos] = value;
    }



}
