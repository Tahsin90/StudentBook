package com.example.dell.studentbook;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class CgpaCalculation_2_activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cgpa_calculation_2_activity);


        String fresult = getIntent().getStringExtra("getCgpa");
        TextView t1 = (TextView)findViewById(R.id.FinalResultET);
        t1.setText(fresult);




    }
}
