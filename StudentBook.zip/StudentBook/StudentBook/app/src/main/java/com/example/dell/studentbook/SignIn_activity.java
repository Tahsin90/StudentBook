package com.example.dell.studentbook;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SignIn_activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in_activity);
    }
}
