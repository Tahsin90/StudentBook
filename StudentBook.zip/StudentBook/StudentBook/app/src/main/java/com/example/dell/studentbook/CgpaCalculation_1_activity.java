package com.example.dell.studentbook;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.util.Log;

public class CgpaCalculation_1_activity extends AppCompatActivity {

    public static String F_Result = "fResult";

    double gpa[]=new double[100];
    double crt[]=new double[100];
    double totalCredit=0.0;
    Global_var obj=new Global_var();
    Button Next,Calculate ;
    double Ch[]=new double[10];
    double Gp[]=new double[10];
    double cgpa=0.0;
    double top=0.0;
    double bottom=0.0;
    int i=0;
    int k=0;
    int gpaCounter=0;
    int creditCounter=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cgpa_calculation_1_activity);
        Next = (Button)findViewById(R.id.NextBtn);
        Calculate = (Button)findViewById(R.id.CalculateBtn);
        final EditText CreditHours =(EditText)findViewById(R.id.CredHoursET);
        final EditText Gpa =(EditText)findViewById(R.id.GpaGetET);

        Next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent i = new Intent(getApplicationContext(),CgpaCalculation_1_activity.class);
//                startActivity(i);
                try{
                    gpa[gpaCounter]=Double.parseDouble(CreditHours.getText().toString());
                    crt[creditCounter]=Double.parseDouble(Gpa.getText().toString());
                    gpaCounter++;
                    creditCounter++;
                }catch(Exception e){
                    Toast.makeText(CgpaCalculation_1_activity.this, "Please enter valid cgpa", Toast.LENGTH_SHORT).show();
                }
                CreditHours.setText("");
                Gpa.setText("");
            }
        });

        Calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                double cgpa=0.0;
                for(int i=0;i<creditCounter;i++){
                    totalCredit+=crt[i];
                }
                for(int i=0;i<creditCounter;i++){
                    cgpa+=crt[0]*gpa[0];
                }
//                String CH =CreditHours.getText().toString();
//                if(!CH.isEmpty())
//                    try
//                    {
//                        Ch[0]= Double.parseDouble(CH);
//                        // it means it is double
//                    } catch (Exception e1) {
//                        // this means it is not double
//                        e1.printStackTrace();
//                    }
//                String GP =Gpa.getText().toString();
//                if(!GP.isEmpty())
//                    try
//                    {
//                        Gp[0]= Double.parseDouble(GP);
//                        k++;
//                        // it means it is double
//                    } catch (Exception e1) {
//                        // this means it is not double
//                        e1.printStackTrace();
//                    }
//                  top=top+Gp[0]*Ch[0];
//                  bottom=bottom+Ch[0];
//                cgpa=top/bottom;
//                Toast.makeText(getApplicationContext(),"Cgpa is"+cgpa+" value of k "+k, Toast.LENGTH_LONG).show();
                Toast.makeText(CgpaCalculation_1_activity.this, (cgpa/totalCredit)+"", Toast.LENGTH_LONG).show();


                String finResult = Calculate.getText().toString();
                Intent i = new Intent(getApplicationContext(),CgpaCalculation_2_activity.class);
                i.putExtra("getCgpa",(cgpa/totalCredit)+"");
                startActivity(i);


            }
        });


    }
}
